package fr.mdr.conceptionobjet.gameoflife.model;

import java.util.Random;
import java.util.Arrays;

public class World {

	private Cell[][] cells;

	public World(int nbColumns, int nbRows) {
		cells = new Cell[nbColumns][nbRows];

		Random random = new Random();

		for (int i = 0; i < cells.length; i++) {
			for (int j = 0; j < cells[i].length; j++) {
				if (random.nextBoolean()) {
					cells[i][j] = new AliveCell();
				} else {
					cells[i][j] = new DeadCell();
				}
			}
		}
	}

	public void newGeneration() {

		Cell[][] tempCells = new Cell[cells.length][cells[0].length];

		for (int i = 0; i < cells.length; i++) {
			for (int j = 0; j < cells[i].length; j++) {
				int nbNeighbourg = countNeighbourgs(i, j);
				Cell nextGenCell = cells[i][j].newGeneration(nbNeighbourg);
				tempCells[i][j] = nextGenCell;
			}
		}

		cells = tempCells;
	}

	public int countNeighbourgs(int x, int y) {

		int nbNeighbourg = 0;

		for (int u = -1; u <= 1; u++) {
			for (int v = -1; v <= 1; v++) {

				
				if (u == 0 && v == 0) {
					continue;// skip current iteration
				}
				
				int xNeighbourg = x + u;
				int yNeighbourg = y + v;
				
				if(xNeighbourg < 0 || yNeighbourg < 0){
                    continue;
                }

				if (xNeighbourg >= cells.length || yNeighbourg >= cells[0].length) {
					continue;
				}
//				System.out.println("[" + xNeighbourg + "," + yNeighbourg + "]");

				if (cells[xNeighbourg][yNeighbourg].isAlive()) {
					nbNeighbourg++;
				}
			}
		}
		return nbNeighbourg;
	}

	@Override
	public String toString() {
		String worldStr = "";

		for (int i = 0; i < cells.length; i++) {
			for (int j = 0; j < cells[i].length; j++) {
				worldStr += cells[i][j].getAString();
			}
			worldStr += "\n";
		}

		return worldStr;
	}

}

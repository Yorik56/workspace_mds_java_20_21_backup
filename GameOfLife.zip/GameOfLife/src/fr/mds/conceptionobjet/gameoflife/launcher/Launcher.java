package fr.mds.conceptionobjet.gameoflife.launcher;

import fr.mdr.conceptionobjet.gameoflife.model.World;

public class Launcher {
	public static void main(String[] args) {
		
		World world = new World(10,10);
		

		
		
		while(true) {
			System.out.println(world);
			world.newGeneration();
			
			try {
				Thread.sleep(1000);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
}

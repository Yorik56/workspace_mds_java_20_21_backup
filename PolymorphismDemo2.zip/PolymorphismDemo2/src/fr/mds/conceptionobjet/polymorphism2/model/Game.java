package fr.mds.conceptionobjet.polymorphism2.model;

public class Game extends Prize {
	@Override
	public int getPrizeValue() {
		return 80;
	}
}

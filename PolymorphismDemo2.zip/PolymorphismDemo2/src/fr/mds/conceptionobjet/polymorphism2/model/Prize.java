package fr.mds.conceptionobjet.polymorphism2.model;

public abstract class Prize {
	public abstract int getPrizeValue();
}

package fr.mds.conceptionobjet.polymorphism2.model;

public class Coupon extends Prize {
	@Override
	public int getPrizeValue() {
		return 100;
	}
}

package fr.mds.conceptionobjet.polymorphism2.model;

public class Trip extends Prize {
	public int getPrizeValue() {
		return 3000;
	}
}

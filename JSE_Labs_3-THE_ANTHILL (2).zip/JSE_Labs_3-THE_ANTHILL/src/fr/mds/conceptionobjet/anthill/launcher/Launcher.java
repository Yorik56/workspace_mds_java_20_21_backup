package fr.mds.conceptionobjet.anthill.launcher;

import java.util.Iterator;
import java.util.Scanner;

import fr.mds.conceptionobjet.anthill.model.Ant;
import fr.mds.conceptionobjet.anthill.model.AntHill;
import fr.mds.conceptionobjet.anthill.model.Larva;
import fr.mds.conceptionobjet.anthill.model.Male;
import fr.mds.conceptionobjet.anthill.model.Queen;
import fr.mds.conceptionobjet.anthill.model.Worker;
import fr.mds.conceptionobjet.fridgeproject.launcher.model.Vegetable;

public class Launcher {
	public static void main(String[] args) {
		// Array who contains the Init Values for the g
		String[] arrayInitGame;
		Scanner question = new Scanner(System.in);
		// Check the Validity of the Answer
		boolean checkValidResponse;
		do {
			checkValidResponse = true;
			// Display the init rules
			System.out.println("Let's initialize the AntHill:");
			System.out.println("nbrOfQueen,nbrOfMales,nbrOfWorkers,nbrOfLarva");
			// Init the question
			String a = question.nextLine();
			// Get the answer
			arrayInitGame = a.split(",");
			for (String item : arrayInitGame) {
				char[] tab = item.toCharArray();
				for (char carac : tab) {
					if (!Character.isDigit(carac) && checkValidResponse) {
						checkValidResponse = false;
					}
				}
			}
		} while (arrayInitGame.length != 4 || checkValidResponse == false);

		// Retrieves the parameters that will be used to instanciate the AntHill
		int queenInit = Integer.parseInt(arrayInitGame[0]);
		int maleInit = Integer.parseInt(arrayInitGame[1]);
		int workerInit = Integer.parseInt(arrayInitGame[2]);
		int larvaInit = Integer.parseInt(arrayInitGame[3]);
		// instantiation of the AntHill
		AntHill myAntHill = new AntHill(queenInit, maleInit, workerInit, larvaInit);

		// Display the begining statistics
		System.out.println("<< Day " + myAntHill.getAgeOfHill() + " >>");
		System.out.println("Total number of ants: " + myAntHill.getNbrOfAnt());
		System.out.println("Number of queen: " + myAntHill.getNbrOfQueens());
		System.out.println("Number of worker: " + myAntHill.getNbrOfWorkers());
		System.out.println("Number of male: " + myAntHill.getNbrOfMales());
		System.out.println("Number of larva: " + myAntHill.getNbrOfLarvas());
		System.out.println("Number of birth: " + myAntHill.getNbrOfBirth());
		System.out.println("Number of death: " + myAntHill.getNbrOfDeath());

		// Check if the game must continue
		boolean live = true;

		// As long as there are ants or "live" is true, the game must go on
		while (myAntHill.getNbrOfAnt() > 0 || live) {
			System.out.println("To continue, press enter to go next day or choose a number of days");
			String b = question.nextLine();
			boolean checkInt = true;
			String[] arrayResp = b.split("");
			for (String item : arrayResp) {
				char[] tab = item.toCharArray();
				for (char carac : tab) {
					if (!Character.isDigit(carac) && checkInt) {
						checkInt = false;
					}
				}
			}

			if (!checkInt) {
				System.out.println("Please enter a numeric value.");
			} else {
				int response;
				if (b.equals("")) {
					response = 1;
				} else {
					response = Integer.parseInt(b);
				}
				System.out.println("+ " + response + " jours");
				myAntHill.setAgeOfHill(response);
				System.out.println("<< Day " + myAntHill.getAgeOfHill() + " >>");
				System.out.println("Total number of ants: " + myAntHill.getNbrOfAnt());
				System.out.println("Number of queen: " + myAntHill.getNbrOfQueens());
				System.out.println("Number of worker: " + myAntHill.getNbrOfWorkers());
				System.out.println("Number of male: " + myAntHill.getNbrOfMales());
				System.out.println("Number of larva: " + myAntHill.getNbrOfLarvas());
				System.out.println("Number of birth: " + myAntHill.getNbrOfBirth());
				System.out.println("Number of death: " + myAntHill.getNbrOfDeath());
				
				Iterator<Ant> iterANTor = myAntHill.getArrAnt().iterator();
				
				while(iterANTor.hasNext()) {
					
					Vegetable v = it.next();
//					System.out.println("here vegetable");
//					System.out.println(v.getName());
//					System.out.println(v.getConservationTime());
					
					if(v.getConservationTime() < dayCount) {
						System.out.println("Removing " + v.getName() + " because it's rotten");
						it.remove();
					}
					
				}
				
				for (Ant currentAnt : myAntHill.getArrAnt()) {
			
					currentAnt.setAge(response);
					if (currentAnt.getAge() >= currentAnt.getAgeMax()) {
						if (currentAnt.getCast() == "larva") {
							System.out.println("nouvel adulte");

							if (((Larva) currentAnt).getAdultCast() == "queen") {
//								Queen queen = new Queen(myAntHill.getLastId(), 50, "queen");
//								myAntHill.getArrAnt().add(queen);
//								myAntHill.setNbrOfAnt(1);
//								myAntHill.setLastId(1);
								System.out.println("ok q");
							}else if(((Larva) currentAnt).getAdultCast() == "male"){
//								Male male = new Male(myAntHill.getLastId(), 20, "male");
//								myAntHill.getArrAnt().add(male);
//								myAntHill.setNbrOfAnt(1);
//								myAntHill.setLastId(1);
								System.out.println("ok m");
							}else if(((Larva) currentAnt).getAdultCast() == "worker"){
//								Worker worker = new Worker(myAntHill.getLastId(), 50, "worker");
//								myAntHill.getArrAnt().add(worker);
//								myAntHill.setNbrOfAnt(1);
//								myAntHill.setLastId(1);
								System.out.println("ok w");
							}
//							System.out.println("remove");
							myAntHill.getArrAnt().remove(currentAnt.getIdentifier());
							System.out.println("read");
							System.out.println("Fourmis n� " + currentAnt.getIdentifier() + " caste: " + currentAnt.getCast()
							+ " age: " + currentAnt.getAge());
							System.out.println("postread");
						} else {
							System.out.println("Une fourmis est morte");
						}
					}else {
						System.out.println("Fourmis n� " + currentAnt.getIdentifier() + " caste: " + currentAnt.getCast()
						+ " age: " + currentAnt.getAge());
					}
					
				}
			}
		}
		question.close();
	}
}

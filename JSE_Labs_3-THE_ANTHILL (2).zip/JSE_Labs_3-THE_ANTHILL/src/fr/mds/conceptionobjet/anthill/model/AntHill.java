package fr.mds.conceptionobjet.anthill.model;

import java.util.ArrayList;
import java.util.List;

public class AntHill {
	private int nbrOfQueens = 0;
	private int nbrOfMales = 0;
	private int nbrOfWorkers = 0;
	private int nbrOfLarvas = 0;
	private int ageOfHill = 0;
	private int nbrOfAnt = 0;
	private int nbrOfBirth = 0;
	private int nbrOfDeath = 0;
	private int lastId = 0;
	private List<Ant> arrAnt = new ArrayList<Ant>();

	public AntHill(int nbrOfQueens, int nbrOfMales, int nbrOfWorkers, int nbrOfLarvas) {

		for (int i = 0; i < nbrOfQueens; i++) {
			Queen queen = new Queen(lastId, 50, "queen");
			this.arrAnt.add(queen);
			this.setNbrOfAnt(1);
			this.lastId++;
		}
		this.nbrOfQueens = nbrOfQueens;

		for (int i = 0; i < nbrOfMales; i++) {
			Male male = new Male(lastId, 20, "male");
			this.arrAnt.add(male);
			this.setNbrOfAnt(1);
			this.lastId++;
		}
		this.nbrOfMales = nbrOfMales;

		for (int i = 0; i < nbrOfWorkers; i++) {
			Worker worker = new Worker(lastId, 50, "worker");
			this.arrAnt.add(worker);
			this.setNbrOfAnt(1);
			this.lastId++;
		}
		this.nbrOfWorkers = nbrOfWorkers;

		for (int i = 0; i < nbrOfLarvas; i++) {
			Larva larva = new Larva(lastId, 10, "larva");
			this.arrAnt.add(larva);
			this.setNbrOfAnt(1);
			this.lastId++;
		}
		this.nbrOfLarvas = nbrOfLarvas;

	}

	public int getNbrOfAnt() {
		return nbrOfAnt;
	}

	public void setNbrOfAnt(int nbrOfAntAdd) {
		this.nbrOfAnt = this.nbrOfAnt + nbrOfAntAdd;
	}

	public int getNbrOfQueens() {
		return nbrOfQueens;
	}

	public void setNbrOfQueens(int nbrOfQueens) {
		this.nbrOfQueens = nbrOfQueens;
	}

	public int getNbrOfMales() {
		return nbrOfMales;
	}

	public void setNbrOfMales(int nbrOfMales) {
		this.nbrOfMales = nbrOfMales;
	}

	public int getNbrOfWorkers() {
		return nbrOfWorkers;
	}

	public void setNbrOfWorkers(int nbrOfWorkers) {
		this.nbrOfWorkers = nbrOfWorkers;
	}

	public int getNbrOfLarvas() {
		return nbrOfLarvas;
	}

	public void setNbrOfLarvas(int nbrOfLarvas) {
		this.nbrOfLarvas = nbrOfLarvas;
	}

	public int getAgeOfHill() {
		return ageOfHill;
	}

	public void setAgeOfHill(int ageOfHill) {
		this.ageOfHill = this.ageOfHill + ageOfHill;
	}

	public int getNbrOfBirth() {
		return nbrOfBirth;
	}

	public void setNbrOfBirth(int nbrOfBirth) {
		this.nbrOfBirth = nbrOfBirth;
	}

	public int getNbrOfDeath() {
		return nbrOfDeath;
	}

	public void setNbrOfDeath(int nbrOfDeath) {
		this.nbrOfDeath = nbrOfDeath;
	}

	public int getLastId() {
		return lastId;
	}

	public void setLastId(int lastId) {
		this.lastId = this.lastId + lastId;
	}

	public List<Ant> getArrAnt() {
		return arrAnt;
	}
}

package fr.mds.conceptionobjet.anthill.launcher;


import java.util.Scanner;

import fr.mds.conceptionobjet.anthill.model.AntHill;

public class Launcher {
	public static void main(String[] args) {
		String[] arrayA;
		Scanner question = new Scanner(System.in);
		do {
			System.out.println("Let's initialize the AntHill:");
			System.out.println("nbrOfQueen,nbrOfMales,nbrOfWorkers,nbrOfLarva");
			String a = question.nextLine();
			arrayA = a.split(",");
		}while(arrayA.length != 4);
		int queenInit = Integer.parseInt(arrayA[0]);
		int maleInit = Integer.parseInt(arrayA[1]);
		int workerInit = Integer.parseInt(arrayA[2]);
		int larvaInit = Integer.parseInt(arrayA[3]);
		
		AntHill myAntHill = new AntHill(queenInit,maleInit,workerInit,larvaInit);
		System.out.println("<< Jour 0 >>");
		System.out.println("Nombre total de fourmis: " + myAntHill.getNbrOfAnt());
		System.out.println("Nombre de reines: " + myAntHill.getNbrOfQueens());
		System.out.println("Nombre de travailleuses: " + myAntHill.getNbrOfWorkers());
		System.out.println("Nombre de m�les: " + myAntHill.getNbrOfMales());
		System.out.println("Nombre de larves: " + myAntHill.getNbrOfLarvas());
		boolean live = true;
		
		while(myAntHill.getNbrOfAnt() > 0 || live ) {
			System.out.println("Please type a number");
			
			int b = question.nextInt();
			System.out.println(b);
			
		}
		question.close();
		
	}
}

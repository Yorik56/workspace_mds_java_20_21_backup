package fr.mds.conceptionobjet.anthill.model;

public abstract class Ant {
	protected int identifier;
	protected int age;
	protected int ageMax;

	public Ant(int identifier,int ageMax) {
		this.identifier = identifier;
		this.ageMax = ageMax;
	}

	public abstract int getAge();

	public abstract void setAge(int age);

	public abstract int getAgeMax();

	public abstract void setAgeMax(int ageMax);

}

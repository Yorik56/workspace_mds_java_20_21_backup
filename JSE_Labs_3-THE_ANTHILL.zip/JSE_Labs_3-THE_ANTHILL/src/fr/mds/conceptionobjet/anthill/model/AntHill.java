package fr.mds.conceptionobjet.anthill.model;

import java.util.ArrayList;
import java.util.List;

public class AntHill {
	private int nbrOfQueens;
	private int nbrOfMales;
	private int nbrOfWorkers;
	private int nbrOfLarvas;
	private int ageOfHill;
	private int nbrOfAnt;
	private int nbrOfBirth;
	private int nbrOfDeath;
	private List<Ant> arrAnt = new ArrayList<Ant>();

	public AntHill(int nbrOfQueens, int nbrOfMales, int nbrOfWorkers, int nbrOfLarvas) {
		
		for (int i = 0; i < nbrOfQueens; i++) {
			Queen queen = new Queen(arrAnt.size() + 1, 50);
			this.arrAnt.add(queen);
			this.setNbrOfAnt(1);
		}		
		this.nbrOfQueens = nbrOfQueens;
		
		for (int i = 0; i < nbrOfMales; i++) {
			Male male = new Male(arrAnt.size() + 1, 20);
			this.arrAnt.add(male);
			this.setNbrOfAnt(1);
		}	
		this.nbrOfMales = nbrOfMales;
		
		for (int i = 0; i < nbrOfWorkers; i++) {
			Worker worker = new Worker(arrAnt.size() + 1, 50);
			this.arrAnt.add(worker);
			this.setNbrOfAnt(1);
		}	
		this.nbrOfWorkers = nbrOfWorkers;
		
		for (int i = 0; i < nbrOfLarvas; i++) {
			Larva larva = new Larva(arrAnt.size() + 1, 10);
			this.arrAnt.add(larva);
			this.setNbrOfAnt(1);
		}
		this.nbrOfLarvas = nbrOfLarvas;
		
	}

	public int getNbrOfAnt() {
		return nbrOfAnt;
	}

	public void setNbrOfAnt(int nbrOfAntAdd) {
		this.nbrOfAnt = this.nbrOfAnt + nbrOfAntAdd;
	}

	public int getNbrOfQueens() {
		return nbrOfQueens;
	}

	public void setNbrOfQueens(int nbrOfQueens) {
		this.nbrOfQueens = nbrOfQueens;
	}

	public int getNbrOfMales() {
		return nbrOfMales;
	}

	public void setNbrOfMales(int nbrOfMales) {
		this.nbrOfMales = nbrOfMales;
	}

	public int getNbrOfWorkers() {
		return nbrOfWorkers;
	}

	public void setNbrOfWorkers(int nbrOfWorkers) {
		this.nbrOfWorkers = nbrOfWorkers;
	}

	public int getNbrOfLarvas() {
		return nbrOfLarvas;
	}

	public void setNbrOfLarvas(int nbrOfLarvas) {
		this.nbrOfLarvas = nbrOfLarvas;
	}

	public int getAgeOfHill() {
		return ageOfHill;
	}

	public void setAgeOfHill(int ageOfHill) {
		this.ageOfHill = ageOfHill;
	}

	public int getNbrOfBirth() {
		return nbrOfBirth;
	}

	public void setNbrOfBirth(int nbrOfBirth) {
		this.nbrOfBirth = nbrOfBirth;
	}

	public int getNbrOfDeath() {
		return nbrOfDeath;
	}

	public void setNbrOfDeath(int nbrOfDeath) {
		this.nbrOfDeath = nbrOfDeath;
	}

}

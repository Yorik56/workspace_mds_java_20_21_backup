package fr.mds.conceptionobjet.anthill.model;

public class Worker extends Ant {
	public Worker(int identifier,int ageMax) {
		super(identifier, ageMax);
	}

	@Override
	public int getAge() {
		return this.age;
	}

	@Override
	public void setAge(int age) {
		this.age = age;
	}

	@Override
	public int getAgeMax() {
		return this.ageMax;
	}

	@Override
	public void setAgeMax(int ageMax) {
		this.ageMax = ageMax;
	}
}

package fr.mds.conceptionobjet.model;

public class Flower extends Vegetal {
	public void wither() {
		System.out.println("Flower withering");
	}
}

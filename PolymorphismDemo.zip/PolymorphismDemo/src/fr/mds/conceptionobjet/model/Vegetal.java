package fr.mds.conceptionobjet.model;

public class Vegetal {
	public void grow() {
		System.out.println("Vegetal is growing");
	}
}

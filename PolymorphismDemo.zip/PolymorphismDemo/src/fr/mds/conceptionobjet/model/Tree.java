package fr.mds.conceptionobjet.model;

public class Tree extends Vegetal {
	public void loseleaf() {
		System.out.println("losing leaves");
	}
}
